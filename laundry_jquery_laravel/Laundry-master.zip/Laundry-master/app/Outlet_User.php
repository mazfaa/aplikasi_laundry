<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Outlet_User extends Model
{
    protected $table = 'outlet_user';
    protected $guarded = [];
}
