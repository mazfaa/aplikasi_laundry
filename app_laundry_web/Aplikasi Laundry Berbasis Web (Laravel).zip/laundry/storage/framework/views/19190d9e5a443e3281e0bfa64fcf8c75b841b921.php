<a href="<?php echo e(route('product.edit',[$id])); ?>"
    class="btn btn-success btn-sm shadow-sm"
    data-toggle="tooltip"
    data-placement="top"
    title="Edit">
    <i class="fa fa-pen"></i>
</a>
<a href="<?php echo e(route('product.destroy',[$id])); ?>"
    class="btn btn-danger btn-sm shadow-sm delete-data"
    data-toggle="tooltip"
    data-placement="top"
    title="Delete">
    <i class="fa fa-times"></i>
</a>
<?php /**PATH C:\laragon\www\laundry\resources\views/backend/product/index-action.blade.php ENDPATH**/ ?>