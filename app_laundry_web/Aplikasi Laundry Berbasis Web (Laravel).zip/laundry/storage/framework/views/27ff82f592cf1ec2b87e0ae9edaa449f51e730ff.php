<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-left justify-content-left" href="#">
        <div class="sidebar-brand-text"><?php echo e(App\Setting::where('slug','nama-toko')->get()->first()->description); ?></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Menu Utama
    </div>
    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php echo e(active('dashboard')); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
            <i class="fas fa-fw fa-home"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
        Addons
    </div>
    <li class="nav-item <?php echo e(active('product.index')); ?>">
        <a class="nav-link" href="<?php echo e(route('product.index')); ?>">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Produk</span>
        </a>
    </li>
    <li class="nav-item <?php echo e(active('customer.index')); ?>">
        <a class="nav-link" href="<?php echo e(route('customer.index')); ?>">
            <i class="fas fa-fw fa-user"></i>
            <span>Customer</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(is_active('transaction.*') ? '':'collapsed'); ?>" href="#" data-toggle="collapse" data-target="#transaksi" aria-expanded="true" aria-controls="transaksi">
            <i class="fas fa-fw fa-book"></i>
            <span>Transaksi</span>
        </a>
        <div id="transaksi" class="collapse <?php echo e(is_active('transaction.*')  ? 'show':''); ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item <?php echo e(active('transaction.create')); ?>" href="<?php echo e(route('transaction.create')); ?>">Transaksi</a>
            <a class="collapse-item <?php echo e(active('transaction.index')); ?>" href="<?php echo e(route('transaction.index')); ?>">List Transaksi</a>
            <a class="collapse-item <?php echo e(active('transaction.history')); ?>" href="<?php echo e(route('transaction.history')); ?>">Riwayat Transaksi</a>
            </div>
        </div>
    </li>
    <li class="nav-item <?php echo e(active('setting.index')); ?>">
        <a class="nav-link" href="<?php echo e(route('setting.index')); ?>">
            <i class="fas fa-fw fa-cog"></i>
            <span>Setting</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(is_active('user.index') || is_active('role.index') ? '':'collapsed'); ?>" href="#" data-toggle="collapse" data-target="#user" aria-expanded="true" aria-controls="user">
            <i class="fas fa-fw fa-user"></i>
            <span>Manajemen Pengguna</span>
        </a>
        <div id="user" class="collapse <?php echo e(is_active('user.index') || is_active('role.index')  ? 'show':''); ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item <?php echo e(active('user.index')); ?>" href="<?php echo e(route('user.index')); ?>">Pengguna</a>
            <a class="collapse-item <?php echo e(active('role.index')); ?>" href="<?php echo e(route('role.index')); ?>">Hak Akses</a>
            </div>
        </div>
    </li>
    

</ul>
<!-- End of Sidebar -->
<?php /**PATH C:\laragon\www\laundry\resources\views/backend/component/sidebar.blade.php ENDPATH**/ ?>