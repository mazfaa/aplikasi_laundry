<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo e(App\Setting::where('slug','nama-toko')->get()->first()->description); ?> <?php echo e(date('Y')); ?> | Repost by <a href='https://stokcoding.com/' title='StokCoding.com' target='_blank'>StokCoding.com</a>
            </span>
        </div>
    </div>
</footer>
<!-- End of Footer -->
<?php /**PATH C:\laragon\www\laundry\resources\views/backend/component/footer.blade.php ENDPATH**/ ?>