<?php if(session()->has('success-message')): ?>
    <div class="col-lg-12">
        <div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>

        <span class="sr-only">Close</span>
                    </button>

            <?php echo e(session()->get('success-message')); ?>

        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\laundry\resources\views/backend/component/success.blade.php ENDPATH**/ ?>