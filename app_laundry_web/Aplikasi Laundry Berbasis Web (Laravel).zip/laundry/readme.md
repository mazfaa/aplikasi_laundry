## Laundry

![](screenshoot/Login.png)

Aplikasi Laundry simple dibangun dengan laravel 5.8 dan Mysql

## Fitur

1. Management Pengguna
2. Management Produk
3. Management Customer
4. Management Transaksi
5. Management List Transaksi
6. Management Setting Aplikasi
7. Management Print Kuitansi Transaksi
8. Management Export Data Transaksi Via Excel


